'use client';

import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useState } from 'react';

export function CreateQuiz() {
  const [formData, setFormData] = useState({
    subject: 'math',
    difficulty: 'medium',
    questions: 10,
  });
  const [isGenerating, setIsGenerating] = useState(false);
  const [isComplete, setIsComplete] = useState(false);

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: name === 'questions' ? parseInt(value) : value,
    }));
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsGenerating(true);

    // Simulate quiz generation
    await new Promise((resolve) => setTimeout(resolve, 2000));

    setIsGenerating(false);
    setIsComplete(true);

    // Reset after 3 seconds
    setTimeout(() => {
      setIsComplete(false);
      setFormData({
        subject: 'math',
        difficulty: 'medium',
        questions: 10,
      });
    }, 3000);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Create Custom Quiz</h1>
        <p className="text-gray-600">Generate a personalized practice quiz with AI</p>
      </div>

      {isComplete ? (
        <Card className="p-8 bg-green-50 border-0 shadow-sm text-center">
          <div className="text-4xl mb-4">✓</div>
          <h2 className="text-2xl font-bold text-green-700 mb-2">
            Quiz Created Successfully!
          </h2>
          <p className="text-green-600 mb-6">
            Your {formData.questions} question {formData.subject} quiz is ready.
          </p>
          <Button className="bg-green-600 hover:bg-green-700 text-white px-8 font-semibold">
            Start Quiz
          </Button>
        </Card>
      ) : (
        <Card className="p-8 bg-white border border-gray-200 shadow-sm">
          <form onSubmit={handleGenerate} className="space-y-6">
            {/* Subject Selection */}
            <div>
              <label className="block text-sm font-semibold text-gray-900 mb-3">
                Subject
              </label>
              <div className="grid grid-cols-3 gap-3">
                {['math', 'reading', 'writing'].map((subject) => (
                  <button
                    key={subject}
                    type="button"
                    onClick={() =>
                      setFormData((prev) => ({ ...prev, subject }))
                    }
                    className={`p-4 rounded-lg font-medium capitalize transition-colors border-2 ${
                      formData.subject === subject
                        ? 'border-blue-500 bg-blue-50 text-blue-700'
                        : 'border-gray-300 bg-white text-gray-700 hover:border-gray-400'
                    }`}
                  >
                    {subject}
                  </button>
                ))}
              </div>
            </div>

            {/* Difficulty Selection */}
            <div>
              <label className="block text-sm font-semibold text-gray-900 mb-3">
                Difficulty
              </label>
              <div className="grid grid-cols-3 gap-3">
                {['easy', 'medium', 'hard'].map((difficulty) => (
                  <button
                    key={difficulty}
                    type="button"
                    onClick={() =>
                      setFormData((prev) => ({ ...prev, difficulty }))
                    }
                    className={`p-4 rounded-lg font-medium capitalize transition-colors border-2 ${
                      formData.difficulty === difficulty
                        ? 'border-blue-500 bg-blue-50 text-blue-700'
                        : 'border-gray-300 bg-white text-gray-700 hover:border-gray-400'
                    }`}
                  >
                    {difficulty}
                  </button>
                ))}
              </div>
            </div>

            {/* Number of Questions */}
            <div>
              <label htmlFor="questions" className="block text-sm font-semibold text-gray-900 mb-3">
                Number of Questions
              </label>
              <div className="flex items-center gap-4">
                <Input
                  id="questions"
                  type="number"
                  name="questions"
                  min="1"
                  max="50"
                  value={formData.questions}
                  onChange={handleInputChange}
                  className="w-20 border-gray-300 focus:ring-blue-500 focus:border-blue-500"
                />
                <input
                  type="range"
                  name="questions"
                  min="1"
                  max="50"
                  value={formData.questions}
                  onChange={handleInputChange}
                  className="flex-1 h-2 bg-gray-300 rounded-lg appearance-none cursor-pointer accent-blue-500"
                />
                <span className="text-sm text-gray-600 font-medium w-12 text-right">
                  {formData.questions}
                </span>
              </div>
            </div>

            {/* Summary */}
            <Card className="p-4 bg-blue-50 border-0">
              <p className="text-sm text-gray-700">
                Generate a <span className="font-semibold">{formData.difficulty}</span> {formData.subject} quiz with{' '}
                <span className="font-semibold">{formData.questions} questions</span>
              </p>
            </Card>

            {/* Submit Button */}
            <Button
              type="submit"
              disabled={isGenerating}
              className="w-full bg-blue-500 hover:bg-blue-600 text-white font-semibold py-3 rounded-lg"
            >
              {isGenerating ? (
                <span className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  Generating Quiz...
                </span>
              ) : (
                'Generate with AI'
              )}
            </Button>
          </form>
        </Card>
      )}
    </div>
  );
}
