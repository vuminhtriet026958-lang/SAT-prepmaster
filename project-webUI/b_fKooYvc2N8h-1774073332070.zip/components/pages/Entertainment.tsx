'use client';

import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

type EntertainmentProps = {
  wrongAnswers: number;
};

export function Entertainment({ wrongAnswers }: EntertainmentProps) {
  // Calculate penalty: -1 minute per 2 wrong answers
  const minutePenalty = Math.floor(wrongAnswers / 2);
  
  const sections = [
    { minutes: 5, label: '5 min', color: 'bg-amber-50', textColor: 'text-amber-700' },
    { minutes: 10, label: '10 min', color: 'bg-orange-50', textColor: 'text-orange-700' },
    { minutes: 15, label: '15 min', color: 'bg-red-50', textColor: 'text-red-700' },
  ];

  const availableMinutes = {
    5: Math.max(0, 5 - minutePenalty),
    10: Math.max(0, 10 - minutePenalty),
    15: Math.max(0, 15 - minutePenalty),
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Entertainment Rewards</h1>
        <p className="text-gray-600">Unlock entertainment content based on your progress</p>
      </div>

      {/* Penalty Warning */}
      {wrongAnswers > 0 && (
        <Card className="p-6 bg-red-50 border-0 shadow-sm">
          <div className="flex items-start gap-3">
            <span className="text-2xl">⚠️</span>
            <div>
              <p className="font-semibold text-red-900 mb-1">Time Penalty Applied</p>
              <p className="text-red-700">
                Wrong: {wrongAnswers} → {minutePenalty} {minutePenalty === 1 ? 'minute' : 'minutes'} deducted from each section
              </p>
            </div>
          </div>
        </Card>
      )}

      {/* Content Sections */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {sections.map((section) => (
          <Card
            key={section.minutes}
            className={`p-6 border-0 shadow-sm ${section.color}`}
          >
            <div className="mb-6">
              <h2 className={`text-3xl font-bold ${section.textColor} mb-2`}>
                {section.label}
              </h2>
              <p className="text-sm text-gray-600">
                Available: {availableMinutes[section.minutes as keyof typeof availableMinutes]}/{section.minutes} min
              </p>
            </div>

            {/* Content Items */}
            <div className="space-y-3 mb-6">
              <div className="bg-white bg-opacity-60 p-3 rounded-lg">
                <p className="font-medium text-gray-900">Podcast</p>
                <p className="text-sm text-gray-600">SAT Tips & Tricks</p>
              </div>
              <div className="bg-white bg-opacity-60 p-3 rounded-lg">
                <p className="font-medium text-gray-900">Video</p>
                <p className="text-sm text-gray-600">Grammar Explained</p>
              </div>
              <div className="bg-white bg-opacity-60 p-3 rounded-lg">
                <p className="font-medium text-gray-900">Article</p>
                <p className="text-sm text-gray-600">Test Strategy Guide</p>
              </div>
            </div>

            {/* Action Button */}
            <Button
              disabled={availableMinutes[section.minutes as keyof typeof availableMinutes] === 0}
              className={`w-full font-semibold py-2 rounded-lg transition-colors ${
                availableMinutes[section.minutes as keyof typeof availableMinutes] > 0
                  ? 'bg-blue-500 hover:bg-blue-600 text-white'
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
            >
              {availableMinutes[section.minutes as keyof typeof availableMinutes] > 0
                ? `Unlock (${availableMinutes[section.minutes as keyof typeof availableMinutes]}m)`
                : 'Time Expired'}
            </Button>
          </Card>
        ))}
      </div>

      {/* Info Section */}
      <Card className="p-6 bg-blue-50 border-0 shadow-sm">
        <h3 className="font-semibold text-gray-900 mb-3">How Rewards Work</h3>
        <ul className="space-y-2 text-sm text-gray-700">
          <li className="flex gap-2">
            <span className="text-blue-600 font-bold">•</span>
            <span>Each practice quiz gives you access to entertainment content</span>
          </li>
          <li className="flex gap-2">
            <span className="text-blue-600 font-bold">•</span>
            <span>Wrong answers reduce your available time</span>
          </li>
          <li className="flex gap-2">
            <span className="text-blue-600 font-bold">•</span>
            <span>Accuracy matters - get more questions right to unlock more content</span>
          </li>
          <li className="flex gap-2">
            <span className="text-blue-600 font-bold">•</span>
            <span>Content resets daily for a fresh set of rewards</span>
          </li>
        </ul>
      </Card>
    </div>
  );
}
