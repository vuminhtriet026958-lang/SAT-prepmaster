'use client';

import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

type DashboardProps = {
  onPageChange: (page: string) => void;
  userData: {
    level: number;
    exp: number;
    maxExp: number;
    streak: number;
    accuracy: number;
    quizzesCompleted: number;
  };
};

export function Dashboard({
  onPageChange,
  userData,
}: DashboardProps) {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-4xl font-bold text-gray-900 mb-2">
          Welcome Back!
        </h1>
        <p className="text-lg text-gray-600">
          Keep practicing to improve your SAT score.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-6 bg-blue-50 border-0 shadow-sm">
          <div className="text-sm text-gray-600 font-medium mb-2">Level</div>
          <div className="text-3xl font-bold text-blue-600">{userData.level}</div>
          <p className="text-xs text-gray-500 mt-2">{userData.exp}/{userData.maxExp} XP</p>
        </Card>

        <Card className="p-6 bg-green-50 border-0 shadow-sm">
          <div className="text-sm text-gray-600 font-medium mb-2">Accuracy</div>
          <div className="text-3xl font-bold text-green-600">{userData.accuracy}%</div>
          <p className="text-xs text-gray-500 mt-2">Current rate</p>
        </Card>

        <Card className="p-6 bg-orange-50 border-0 shadow-sm">
          <div className="text-sm text-gray-600 font-medium mb-2">Streak</div>
          <div className="text-3xl font-bold text-orange-600">{userData.streak}</div>
          <p className="text-xs text-gray-500 mt-2">Days in a row</p>
        </Card>

        <Card className="p-6 bg-purple-50 border-0 shadow-sm">
          <div className="text-sm text-gray-600 font-medium mb-2">Quizzes</div>
          <div className="text-3xl font-bold text-purple-600">
            {userData.quizzesCompleted}
          </div>
          <p className="text-xs text-gray-500 mt-2">Completed</p>
        </Card>
      </div>

      {/* Quick Actions */}
      <div>
        <h2 className="text-xl font-bold text-gray-900 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Button
            onClick={() => onPageChange('practice')}
            className="h-24 bg-blue-500 hover:bg-blue-600 text-white text-lg font-semibold rounded-xl shadow-sm"
          >
            Start Practice
          </Button>
          <Button
            onClick={() => onPageChange('ai-tutor')}
            variant="outline"
            className="h-24 border-2 border-gray-300 hover:bg-gray-50 text-gray-900 text-lg font-semibold rounded-xl"
          >
            Ask AI Tutor
          </Button>
          <Button
            onClick={() => onPageChange('create-quiz')}
            variant="outline"
            className="h-24 border-2 border-gray-300 hover:bg-gray-50 text-gray-900 text-lg font-semibold rounded-xl"
          >
            Create Quiz
          </Button>
        </div>
      </div>

      {/* Recent Activity */}
      <div>
        <h2 className="text-xl font-bold text-gray-900 mb-4">Recent Activity</h2>
        <Card className="p-6 bg-white border border-gray-200 shadow-sm">
          <div className="space-y-4">
            <div className="flex items-center justify-between py-3 border-b border-gray-200">
              <div>
                <p className="font-medium text-gray-900">Math Quiz</p>
                <p className="text-sm text-gray-500">Today at 2:30 PM</p>
              </div>
              <span className="text-green-600 font-medium">8/10</span>
            </div>
            <div className="flex items-center justify-between py-3 border-b border-gray-200">
              <div>
                <p className="font-medium text-gray-900">Reading Practice</p>
                <p className="text-sm text-gray-500">Yesterday at 4:15 PM</p>
              </div>
              <span className="text-blue-600 font-medium">+120 XP</span>
            </div>
            <div className="flex items-center justify-between py-3">
              <div>
                <p className="font-medium text-gray-900">AI Tutoring Session</p>
                <p className="text-sm text-gray-500">2 days ago</p>
              </div>
              <span className="text-green-600 font-medium">+85 XP</span>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
