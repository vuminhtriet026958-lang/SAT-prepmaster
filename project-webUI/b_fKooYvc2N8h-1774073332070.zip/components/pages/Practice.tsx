'use client';

import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { useState } from 'react';

type PracticeProps = {
  onWrongAnswer: (count: number) => void;
};

const QUESTIONS = {
  math: [
    {
      id: 1,
      text: 'If 3x + 5 = 20, what is the value of x?',
      options: ['A) 3', 'B) 5', 'C) 7', 'D) 9'],
      correct: 1,
      explanation: '3x + 5 = 20 → 3x = 15 → x = 5',
    },
    {
      id: 2,
      text: 'What is the area of a circle with radius 5?',
      options: ['A) 25π', 'B) 50π', 'C) 10π', 'D) 15π'],
      correct: 0,
      explanation: 'Area = πr² = π(5)² = 25π',
    },
  ],
  reading: [
    {
      id: 3,
      text: 'Which of the following best describes the main idea of the passage?',
      options: ['A) Technology advances', 'B) History of science', 'C) Environmental impact', 'D) Social change'],
      correct: 2,
      explanation: 'The passage primarily focuses on environmental concerns.',
    },
    {
      id: 4,
      text: 'What does the author imply about future developments?',
      options: ['A) They will be limited', 'B) They are inevitable', 'C) They are unnecessary', 'D) They are uncertain'],
      correct: 1,
      explanation: 'The author suggests that developments will continue.',
    },
  ],
  writing: [
    {
      id: 5,
      text: 'Which sentence is grammatically correct?',
      options: ['A) She dont like it', 'B) She does not like it', 'C) She do not like it', 'D) She not like it'],
      correct: 1,
      explanation: '"Does not" is the correct form with third person singular.',
    },
    {
      id: 6,
      text: 'Identify the error: "The students are going to the library for studying."',
      options: ['A) "are going" should be "is going"', 'B) "to" should be "in"', 'C) "for studying" is wordy', 'D) No error'],
      correct: 2,
      explanation: '"To study" is more concise than "for studying".',
    },
  ],
};

type Tab = 'math' | 'reading' | 'writing';

export function Practice({ onWrongAnswer }: PracticeProps) {
  const [currentTab, setCurrentTab] = useState<Tab>('math');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);
  const [stats, setStats] = useState({
    correct: 0,
    wrong: 0,
    skipped: 0,
  });

  const questions = QUESTIONS[currentTab];
  const currentQuestion = questions[currentQuestionIndex];
  const isCorrect = selectedAnswer === currentQuestion.correct;

  const handleAnswerSelect = (index: number) => {
    setSelectedAnswer(index);
    setShowFeedback(true);

    if (index !== currentQuestion.correct) {
      setStats((prev) => ({
        ...prev,
        wrong: prev.wrong + 1,
      }));
      // Track wrong answer for entertainment penalty
      if ((stats.wrong + 1) % 2 === 0) {
        onWrongAnswer(stats.wrong + 1);
      }
    } else {
      setStats((prev) => ({
        ...prev,
        correct: prev.correct + 1,
      }));
    }
  };

  const handleNext = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex((prev) => prev + 1);
      setSelectedAnswer(null);
      setShowFeedback(false);
    } else {
      // End of quiz
      setCurrentQuestionIndex(0);
      setSelectedAnswer(null);
      setShowFeedback(false);
    }
  };

  const handleTabChange = (tab: Tab) => {
    setCurrentTab(tab);
    setCurrentQuestionIndex(0);
    setSelectedAnswer(null);
    setShowFeedback(false);
    setStats({ correct: 0, wrong: 0, skipped: 0 });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Practice Questions</h1>
        <p className="text-gray-600">Choose a category and start practicing</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-gray-200">
        {(['math', 'reading', 'writing'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => handleTabChange(tab)}
            className={`px-6 py-3 font-medium capitalize border-b-2 transition-colors ${
              currentTab === tab
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="p-4 bg-green-50 border-0 shadow-sm">
          <div className="text-2xl font-bold text-green-600">{stats.correct}</div>
          <p className="text-sm text-gray-600">Correct</p>
        </Card>
        <Card className="p-4 bg-red-50 border-0 shadow-sm">
          <div className="text-2xl font-bold text-red-600">{stats.wrong}</div>
          <p className="text-sm text-gray-600">Wrong</p>
        </Card>
        <Card className="p-4 bg-blue-50 border-0 shadow-sm">
          <div className="text-2xl font-bold text-blue-600">
            {Math.round(
              (stats.correct / (stats.correct + stats.wrong || 1)) * 100
            )}%
          </div>
          <p className="text-sm text-gray-600">Accuracy</p>
        </Card>
      </div>

      {/* Question Card */}
      <Card className="p-8 bg-white border border-gray-200 shadow-sm">
        <div className="mb-6">
          <div className="flex justify-between items-center mb-4">
            <span className="text-sm font-medium text-gray-500">
              Question {currentQuestionIndex + 1} of {questions.length}
            </span>
            <span className="text-sm text-gray-500">
              {currentTab.charAt(0).toUpperCase() + currentTab.slice(1)}
            </span>
          </div>
          <p className="text-lg font-semibold text-gray-900">
            {currentQuestion.text}
          </p>
        </div>

        {/* Answer Options */}
        <div className="space-y-3 mb-6">
          {currentQuestion.options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleAnswerSelect(index)}
              disabled={showFeedback}
              className={`w-full p-4 text-left font-medium rounded-lg border-2 transition-all ${
                selectedAnswer === index
                  ? isCorrect
                    ? 'border-green-500 bg-green-50 text-green-700'
                    : 'border-red-500 bg-red-50 text-red-700'
                  : 'border-gray-300 bg-white text-gray-900 hover:border-blue-300'
              } ${showFeedback && !isCorrect && index === currentQuestion.correct ? 'border-green-500 bg-green-50 text-green-700' : ''}`}
            >
              {option}
            </button>
          ))}
        </div>

        {/* Feedback */}
        {showFeedback && (
          <div className="mb-6">
            <Card
              className={`p-4 border-0 ${
                isCorrect ? 'bg-green-50' : 'bg-red-50'
              }`}
            >
              <p className="font-semibold mb-2">
                {isCorrect ? 'Correct!' : 'Incorrect'}
              </p>
              <p className="text-sm">
                {currentQuestion.explanation}
              </p>
            </Card>
          </div>
        )}

        {/* Next Button */}
        {showFeedback && (
          <Button
            onClick={handleNext}
            className="w-full bg-blue-500 hover:bg-blue-600 text-white font-semibold py-3 rounded-lg"
          >
            {currentQuestionIndex === questions.length - 1
              ? 'Complete Quiz'
              : 'Next Question'}
          </Button>
        )}
      </Card>
    </div>
  );
}
