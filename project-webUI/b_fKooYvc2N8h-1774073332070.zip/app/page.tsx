'use client';

import { MainLayout } from '@/components/layout/MainLayout';
import { Dashboard } from '@/components/pages/Dashboard';
import { Practice } from '@/components/pages/Practice';
import { AITutor } from '@/components/pages/AITutor';
import { CreateQuiz } from '@/components/pages/CreateQuiz';
import { Entertainment } from '@/components/pages/Entertainment';
import { Profile } from '@/components/pages/Profile';
import { useState } from 'react';

type Page = 'dashboard' | 'practice' | 'ai-tutor' | 'create-quiz' | 'entertainment' | 'profile';

type UserData = {
  name: string;
  level: number;
  exp: number;
  maxExp: number;
  streak: number;
  accuracy: number;
  quizzesCompleted: number;
  wrongAnswers: number;
  entertainmentMinutes: number;
};

export default function Home() {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [userData, setUserData] = useState<UserData>({
    name: 'Student',
    level: 5,
    exp: 340,
    maxExp: 500,
    streak: 7,
    accuracy: 82,
    quizzesCompleted: 12,
    wrongAnswers: 0,
    entertainmentMinutes: 30,
  });

  const handleWrongAnswer = (count: number) => {
    setUserData((prev) => ({
      ...prev,
      wrongAnswers: count,
      entertainmentMinutes: Math.max(
        0,
        30 - Math.floor(count / 2)
      ),
    }));
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard onPageChange={setCurrentPage} userData={userData} />;
      case 'practice':
        return <Practice onWrongAnswer={handleWrongAnswer} />;
      case 'ai-tutor':
        return <AITutor />;
      case 'create-quiz':
        return <CreateQuiz />;
      case 'entertainment':
        return <Entertainment wrongAnswers={userData.wrongAnswers} />;
      case 'profile':
        return <Profile userData={userData} />;
      default:
        return null;
    }
  };

  return (
    <MainLayout
      currentPage={currentPage}
      onPageChange={setCurrentPage}
      userData={{
        name: userData.name,
        level: userData.level,
        exp: userData.exp,
        maxExp: userData.maxExp,
        streak: userData.streak,
      }}
    >
      {renderPage()}
    </MainLayout>
  );
}
